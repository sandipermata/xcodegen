//
//  AppDelegate.swift
//  SPM
//
//  Created by Yonas Kolb on 13/8/19.
//  Copyright © 2019 BeemIt. All rights reserved.
//

import UIKit
import Codability

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        true
    }

}
