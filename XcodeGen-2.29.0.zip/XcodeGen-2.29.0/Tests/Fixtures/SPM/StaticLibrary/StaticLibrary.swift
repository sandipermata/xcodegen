import Codability

func doThing() {
    _ = AnyCodable.self
}
