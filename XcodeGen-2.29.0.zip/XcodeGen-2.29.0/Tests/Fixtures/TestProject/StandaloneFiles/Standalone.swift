func standaloneHello() -> String {
    "Hello"
}
