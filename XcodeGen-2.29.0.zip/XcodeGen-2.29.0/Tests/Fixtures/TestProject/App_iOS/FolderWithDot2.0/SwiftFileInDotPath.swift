import Foundation

extension String {
    func printHelloWorld() {
        print("Hello World!")
    }
}
