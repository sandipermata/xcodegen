echo "You ran a script"
