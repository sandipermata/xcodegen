//
//  main.swift
//  NetworkExtension
//
//  Created by Vlad Gorlov on 18.06.21.
//

import Foundation
import NetworkExtension

autoreleasepool {
    NEProvider.startSystemExtensionMode()
}

dispatchMain()
