#import <Foundation/Foundation.h>
#import "XPC_ServiceProtocol.h"

@interface XPC_Service : NSObject <XPC_ServiceProtocol>
@end
