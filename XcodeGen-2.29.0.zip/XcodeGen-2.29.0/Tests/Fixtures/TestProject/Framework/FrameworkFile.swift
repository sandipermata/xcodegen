import Foundation

public struct FrameworkStruct {

    public init() {}
}
