#include <Foundation/Foundation.h>

@interface SLObjC: NSObject
@end
