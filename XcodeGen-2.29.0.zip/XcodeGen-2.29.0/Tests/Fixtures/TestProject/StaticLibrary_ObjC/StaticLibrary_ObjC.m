#include "StaticLibrary_ObjC.h"

@implementation SLObjC

- (NSString *)description {
  return @"Hello, World!";
}

@end
