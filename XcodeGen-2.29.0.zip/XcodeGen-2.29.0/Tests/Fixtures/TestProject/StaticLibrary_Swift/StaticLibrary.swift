
public struct SLSwift {
    public func description() -> String {
        "Hello, World!"
    }
}
