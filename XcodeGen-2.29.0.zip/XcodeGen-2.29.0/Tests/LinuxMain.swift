// LinuxMain.swift
fatalError("Run the tests with `swift test --enable-test-discovery`.")

