#!/bin/bash
set -e

cd Tests/Fixtures/TestProject
./build.sh
