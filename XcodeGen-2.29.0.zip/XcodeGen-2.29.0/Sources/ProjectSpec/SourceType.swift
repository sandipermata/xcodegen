//
//  File.swift
//  
//
//  Created by Yonas Kolb on 1/5/20.
//

import Foundation

public enum SourceType: String {
    case group
    case file
    case folder
}
